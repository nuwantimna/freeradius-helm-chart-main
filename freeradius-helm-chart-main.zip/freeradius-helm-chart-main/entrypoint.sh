#!/bin/sh
set -e

sed -i "s~GITLAB_FREE_RADIUS_AURORA_HOST~${GITLAB_FREE_RADIUS_AURORA_HOST}~g" /etc/freeradius/mods-enabled/sql
sed -i "s~GITLAB_FREE_RADIUS_AURORA_USERNAME~${GITLAB_FREE_RADIUS_AURORA_USERNAME}~g" /etc/freeradius/mods-enabled/sql
sed -i "s~GITLAB_FREE_RADIUS_AURORA_PASSWORD~${GITLAB_FREE_RADIUS_AURORA_PASSWORD}~g" /etc/freeradius/mods-enabled/sql

exec "$@"
